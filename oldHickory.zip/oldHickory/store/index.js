import axios from 'axios';
import { applyMiddleware, createStore } from 'redux';
import loggingMiddleware from 'redux-logger';
import thunkMiddleware from 'redux-thunk';

// middleware(s)
const middleWares = (loggingMiddleware, thunkMiddleware);

const initialState = {
  games: [],
  game: {},
  users: [],
  user: {},
  auth: {},
};

// ACTION TYPES
const FETCH_GAMES = 'FETCH_GAMES';
const FETCH_GAME = 'FETCH_GAME';
const FETCH_USERS = 'FETCH_USERS';
const FETCH_USER = 'FETCH_USER';
const CREATE_USER = 'CREATE_USER';
const SIGN_IN = 'SIGN_IN';
const SET_AUTH = 'SET_AUTH';

// ACTION CREATORS
export const _fetchGames = games => ({ type: FETCH_GAMES, games });
export const _fetchGame = game => ({ type: FETCH_GAME, game });
export const _fetchUsers = users => ({ type: FETCH_USERS, users });
export const _fetchUser = user => ({ type: FETCH_USER, user });
export const _createUser = user => ({ type: CREATE_USER, user });
export const _signIn = user => ({ type: SIGN_IN, user });
export const _setAuth = auth => ({ type: SET_AUTH, auth });

// THUNKS
export const fetchGames = () => {
  return async dispatch => {
    const { data: games } = await axios.get('/api/games');
    dispatch(_fetchGames(games));
  };
};
export const fetchGame = id => {
  return async dispatch => {
    const { data: game } = await axios.get(`/api/games/${id}`);
    dispatch(_fetchGame(game));
  };
};
//
export const fetchUsers = () => {
  return async dispatch => {
    const { data: users } = await axios.get('/api/users');
    dispatch(_fetchUsers(users));
  };
};
export const fetchUser = id => {
  return async dispatch => {
    const { data: user } = await axios.get(`/api/users/${id}`);
    dispatch(_fetchUser(user));
  };
};
export const createUser = credentials => {
  return async dispatch => {
    const { data: user } = await axios.post('/api/users/', credentials);
    dispatch(_createUser(user));
  };
};

///////////////////////////////////////////////////////////////

export const signInWithToken = () => {
  return async dispatch => {
    const token = window.localStorage.getItem('token');
    if (token) {
      const response = await axios.get('/api/auth', {
        header: {
          authorization: token,
        },
      });
      dispatch({ type: 'SET_AUTH', auth: response.data });
    }
  };
};

export const signIn = credentials => {
  return async dispatch => {
    const response = await axios.post('/api/auth', credentials);
    window.localStorage.setItem('token', response.data);
    dispatch(signInWithToken());
  };
};

//////////////////////////////////////////

// REDUCER
const reducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_GAMES:
      return {
        ...state,
        games: action.games,
      };
    case FETCH_GAME:
      return {
        ...state,
        game: action.game,
      };
    case FETCH_USERS:
      return {
        ...state,
        users: action.users,
      };
    case FETCH_USER:
      return {
        ...state,
        user: action.user,
      };
    case CREATE_USER:
      return {
        ...state,
        users: [...state.users, action.user],
      };
    case SET_AUTH:
      return {
        ...state,
        auth: action.auth,
      };
    default:
      return state;
  }
};

const store = createStore(reducer, applyMiddleware(middleWares));

export default store;
