import React, { Component } from 'react';
import { connect } from 'react-redux';
import { fetchGame } from '../store';
import { Link } from 'react-router-dom';

class GameDetails extends Component {
  componentDidMount() {
    this.props.fetchGame(this.props.match.params.id);
  }
  render() {
    const { game } = this.props;
    console.log(this.props.match);
    //

    return (
      <main className="Home">
        <div className="GameDetails">
          <div className="GameText">
            <h1>{game.name}</h1>
            <h4>{game.platform}</h4>
            <p>{game.price}</p>
          </div>

          <div className="GameDescription">
            <p>{game.description}</p>
          </div>
          <div className="GameImage">
            <img src={`/public/${game.imgURL}`}></img>
          </div>
          <p>
            <Link to="/games">Back to games list</Link>
          </p>
        </div>
      </main>
    );
  }
}

const mapStateToProps = state => {
  return {
    game: state.game,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    fetchGame: id => dispatch(fetchGame(id)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(GameDetails);
