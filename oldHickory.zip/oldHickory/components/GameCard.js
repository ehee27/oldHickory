import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

const GameCard = props => {
  const { game } = props;

  return (
    <main className="GameCard">
      <h4>
        <Link to={`/games/${game.id}`}>{game.name}</Link>
      </h4>
      <p>{game.platform}</p>
    </main>
  );
};

export default GameCard;
