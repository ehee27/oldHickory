import React from 'react';
import { connect } from 'react-redux';
import GameCard from './GameCard';

import { useState, useEffect } from 'react';

const Games = props => {
  const { games } = props;
  //
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  //

  useEffect(() => {
    const filteredGames = games.filter(game =>
      game.name.toLowerCase().includes(search.toLowerCase())
    );
    setSearchResults(filteredGames);
  }, [games, search]);
  //

  return (
    <main className="Home">
      <h3>All Games</h3>
      <div className="Form">
        <form className="searchForm" onSubmit={e => e.preventDefault()}>
          <label htmlFor="search">Search games</label>
          <input
            id="search"
            type="text"
            placeholder="Search Games"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </form>
      </div>

      <ul>
        {searchResults.map(game => (
          <GameCard key={game.id} game={game} />
        ))}
      </ul>
    </main>
  );
};

const mapStateToProps = state => {
  return {
    games: state.games,
  };
};

export default connect(mapStateToProps, null)(Games);
