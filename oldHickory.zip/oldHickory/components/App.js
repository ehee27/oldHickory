import React, { useEffect } from 'react';
import Header from './Header';
import Nav from './Nav';
import Home from './Home';
import Games from './Games';
import GameDetails from './GameDetails';
import { HashRouter as Router, Switch, Route } from 'react-router-dom';
import { connect, useSelector, useDispatch } from 'react-redux';
import { signInWithToken } from '../store';
import Footer from './Footer';
import Register from './Register';
import SignIn from './Sign-In';

const App = () => {
  const { auth } = useSelector(state => state);
  const dispatch = useDispatch();
  //
  useEffect(() => {
    dispatch(signInWithToken());
  }, []);

  useEffect(() => {
    if (auth.id) {
      dispatch(fetchCart());
    }
  }, [auth]);

  return (
    <Router>
      <div className="App">
        <Header title="Vintage Video Games" />
        <Nav />

        {auth.id ? <Home /> : <Register />}
        <Switch>
          <Route exact path="/" component={Home} />

          <Route exact path="/games" component={Games} />
          <Route exact path="/sign-in" component={SignIn} />
        </Switch>
      </div>
    </Router>
  );
};

export default App;

// {
//   !!auth.id && (
//     <div>
//       <nav>
//         <Link to="/">Home</Link>
//         <Link to="/cart">Cart</Link>
//       </nav>
//       <Switch>
//         <Route exact path="/" component={Home} />

//         <Route exact path="/games" component={Games} />
//         <Route exact path="/sign-in" component={SignIn} />
//       </Switch>
//     </div>
//   );
// }

// class App extends Component {
//   componentDidMount() {
//     this.props.fetchGames();
//   }

//   render() {
//     // desctuct my auth
//     const { auth } = this.props;
//     console.log(auth.id);
//     return (
//       <Router>
//         <div className="App">
//           <Header title="Vintage Video Games" />
//           <Nav />
//           {auth.id ? <Home /> : <Register />}

//           <Switch>
//             <Route exact path="/" component={Home} />
//             <Route exact path="/games" component={Games} />
//             <Route exact path="/games/:id" component={GameDetails} />
//             <Route exact path="/sign-in" component={Signin} />
//           </Switch>
//           <Footer />
//         </div>
//       </Router>
//     );
//   }
// }

// const mapStateToProps = state => {
//   return {
//     auth: state.auth,
//   };
// };
// const mapDispatchToProps = dispatch => {
//   return {
//     fetchGames: () => dispatch(fetchGames()),
//   };
// };

// export default connect(mapStateToProps, mapDispatchToProps)(App);
