const express = require('express');
const app = express();
const path = require('path');
const { conn, syncAndSeed } = require('./server/db/models');

app.use(express.json());

// static middleware
app.use('/dist', express.static(path.join(__dirname, './dist')));

// access routes via api folder
app.use('/api', require('./server/api'));

//access public
app.use('/public', express.static(path.join(__dirname, './public')));

app.get('*', (req, res, next) => {
  res.sendFile(path.join(__dirname, './public/index.html'));
});

const init = async () => {
  try {
    await conn.authenticate();
    await syncAndSeed();

    const port = process.env.PORT || 3000;
    app.listen(port, () => console.log(`listening on port ${port}`));
  } catch (error) {
    console.log(error);
  }
};

init();
