const Sequelize = require('sequelize');
const conn = new Sequelize(
  process.env.DATABASE_URL || 'postgres://localhost/videoGames'
);
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const JWT = process.env.JWT;

const User = conn.define('users', {
  id: {
    type: Sequelize.UUID,
    primaryKey: true,
    defaultValue: Sequelize.UUIDV4,
  },
  username: {
    type: Sequelize.STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
    unique: true,
  },
  password: {
    type: Sequelize.STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
});

/////// FIRST WE ALWAYS AUTHENTICATE
User.authenticate = async ({ username, password }) => {
  const user = await this.findOne({
    where: {
      username,
    },
  });
  if (user && (await bcrypt.compare(password, user.password))) {
    return jwt.sign({ id: user.id }, JWT);
  }
  const error = new Error('invalid credentials');
  error.status = 401;
  throw error;
};

//////// AFTER AUTHENTICATE WE FIND AND VALIATE TOKEN
// need an id, and the token to verify
User.prototype.findByToken = async token => {
  try {
    const { id } = jwt.verify(token, process.env.JWT);
    const user = await this.findByPk(id);
    if (user) {
      return user;
    }
    throw 'user not found';
  } catch (error) {
    const err = new Error('invalid credentials');
    error.status = 401;
    throw err;
  }
};

// BAT
const Game = conn.define('games', {
  name: {
    type: Sequelize.STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
  platform: {
    type: Sequelize.STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
  genre: {
    type: Sequelize.STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
  price: {
    type: Sequelize.FLOAT,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
  description: {
    type: Sequelize.TEXT,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
  imgURL: {
    type: Sequelize.TEXT,
    allowNull: true,
  },
});

const syncAndSeed = async () => {
  try {
    await conn.sync({ force: true });

    const [
      scott,
      steven,
      jason,
      game1,
      game2,
      game3,
      game4,
      game5,
      game6,
      game7,
      game8,
      game9,
      game10,
    ] = await Promise.all([
      User.create({ username: 'Scottl27', password: 'eheelucas27' }),
      User.create({ username: 'Steven88', password: 'mcbleave21' }),
      User.create({ username: 'Jason79', password: 'johnnywoo79' }),
      Game.create({
        name: 'Super Mario World',
        platform: 'Super NES',
        genre: 'Platform',
        price: 49.99,
        description:
          'A new era of gaming. This game set the tone for the excitement of open world, puzzles, power ups and so much more. All the iconinc characters, all the music and memories of the golden age of video games baked into one epic experience.',
        imgURL: 'Super_Mario_World_Coverart.png',
      }),
      Game.create({
        name: 'Super Mario Kart',
        platform: 'Super NES',
        genre: 'Racing',
        price: 49.99,
        description:
          'One of the most classic games of all time in any genre. All the klassic characters and tracks. Enjoy hours of fun with your friends!',
        imgURL: 'Supermariokart_box.jpeg',
      }),
      Game.create({
        name: 'Sonic The HedgeHog',
        platform: 'Sega Genesis',
        genre: 'Platform',
        price: 49.99,
        description:
          "Sega's flagship hero. The fastest, most badass dude around. Try to catch him if you can, or just watch the blur go by!",
        imgURL: 'Sonic_the_Hedgehog_1_Genesis_box_art.jpg',
      }),
      Game.create({
        name: 'Final Fantasy VII',
        platform: 'PS1',
        genre: 'RPG',
        price: 59.99,
        description:
          "Most call it a masterpiece. Some call it the greatest game ever made period. Without a doubt, one of the game synonomous with the rise of the Playstation. An imense game that set the gold standard for all RPG's to come.",
        imgURL: 'Final_Fantasy_VII_Box_Art.jpg',
      }),
      Game.create({
        name: 'Street Fighter 2',
        platform: 'Super NES',
        genre: 'Fighting',
        price: 49.99,
        description:
          'The fighting game of fighting games. No equal. One of the best arcades ports in history, and to think this gift was given to us way back 1993? Enough said.',
        imgURL: 'snes_street_fighter_ii_2_p_zov0x5.jpg',
      }),
      Game.create({
        name: 'The Legend Of Zelda',
        platform: 'NES',
        genre: 'Platform',
        price: 49.99,
        description:
          "The first game in a long line of masterpieces. Set the tone for open world exploration and quest style games. Iconic characters, music, bosses and levels you'll never forget.",
        imgURL: 'Legend_of_zelda_cover_(with_cartridge)_gold.png',
      }),
      Game.create({
        name: 'Castlevania Synphony of The Night',
        platform: 'PS1',
        genre: 'RPG',
        price: 59.99,
        description:
          'One of the very best in a franchise full of bests. The game the shifter the paradigm, and elevated the 2.5 side-scrolling genre to new levels. Little known when it was released in 1997, but one of the most repsected games of the last 30 years.',
        imgURL: 'Castlevania_SOTN_PAL.jpg',
      }),
      Game.create({
        name: "Mike Tyson's Punchout",
        platform: 'NES',
        genre: 'Sports',
        price: 49.99,
        description:
          "A classic game from the classic system. If you were a young gamer in the 80's, you gamed through all the memorable foes for hours on end with the hopes of getting to get your ass kicked by Mike Tyson. A true grind to get there, and it always went quick.",
        imgURL: 's-l500.jpg',
      }),
      Game.create({
        name: 'NBA Jam',
        platform: 'Sega Genesis',
        genre: 'Sports',
        price: 49.99,
        description:
          "Perhaps one of the first truly great multiplayer sports games. A pop culture icon. You weren't cool unless you player NBA jam. BOOMSHAKALAKA!",
        imgURL: 'Nbajam.jpg',
      }),
      Game.create({
        name: 'Contra',
        platform: 'NES',
        genre: 'Run n Gun',
        price: 49.99,
        description:
          'A classic non stop thrill ride with your partner. Multiple weapons, levels and mean bosses to keep you on your toes. Save the world by blowing up one level at a time. It all started here. Thank you Konami!',
        imgURL: 'Contra_cover.jpg',
      }),
    ]);

    //
  } catch (err) {
    console.log(err);
  }
};

module.exports = {
  conn,
  User,
  Game,
  syncAndSeed,
};
