const Sequelize = require('sequelize');
const conn = new Sequelize(
  process.env.DATABASE_URL || 'postgres://localhost/videoGames'
);

// // models
const { Game } = require('./models');

module.exports = {
  conn,
  User,
  Game,
};
