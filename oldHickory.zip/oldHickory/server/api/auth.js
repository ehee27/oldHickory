const router = require('express').Router();
const { User } = require('../db/models');

// FIRST STEP IS TO AUTHENTICATE
router.post('/', async (req, res, next) => {
  try {
    const user = await User.authenticate(req.body);
    res.json(user);
  } catch (err) {
    next(err);
  }
});

// SECOND IS TO FIND THE TOKEN AND SEND BACK
router.get('/', async (req, res, next) => {
  try {
    const token = await User.findByToken(req.headers.authorization);
    res.json(token);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
