const router = require('express').Router();

// both routers
const gameRouter = require('./game');
// const gloveRouter = require('./glove');
const userRouter = require('./users');

router.use('/games', gameRouter);
router.use('/users', userRouter);

// router.use('/gloves', gloveRouter);

module.exports = router;
